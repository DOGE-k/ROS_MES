from setuptools import find_packages, setup

package_name = "motion_solver"

setup(
    name=package_name,
    version="0.0.0",
    packages=find_packages(),
    data_files=[
        ("share/ament_index/resource_index/packages", ["resource/" + package_name]),
        ("share/" + package_name, ["package.xml"]),
    ],
    install_requires=["setuptools"],
    zip_safe=True,
    maintainer="suren",
    maintainer_email="suren@todo.todo",
    description="task5 motion solver",
    license="Apache-2.0",
    entry_points={
        "console_scripts": [
            "data_process_node = motion_solver.data_process_node:main",
        ],
    },
)
