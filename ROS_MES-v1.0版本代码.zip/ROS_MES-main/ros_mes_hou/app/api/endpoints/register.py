from fastapi import APIRouter, Depends, HTTPException, status, Body
from sqlalchemy.orm import Session

from app.db import models, database
from app.core import security

router = APIRouter()


@router.post("/register")
def register_user(
    username: str = Body(...),
    password: str = Body(...),
    db: Session = Depends(database.get_db)
):
    if len(username.strip()) < 3:
        raise HTTPException(status_code=400, detail="用户名至少需要 3 位")

    if len(password) < 6:
        raise HTTPException(status_code=400, detail="密码至少需要 6 位")

    # 与用户管理接口保持一致：只在未删除的账号里查重，
    # 这样被管理员删除的用户名可以重新注册
    db_user = db.query(models.User).filter(
        models.User.Username == username,
        models.User.del_flag == False,
    ).first()

    if db_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="该用户名已被注册"
        )

    hashed_password = security.get_password_hash(password)
    admin = db.query(models.User).filter(models.User.Type_ID == 1).order_by(models.User.User_ID).first()
    creator_id = admin.User_ID if admin else 1
    new_user = models.User(Username=username, Password=hashed_password, Type_ID=2, Creator_ID=creator_id)

    try:
        db.add(new_user)
        db.commit()
        db.refresh(new_user)

        return {
            "code": 200,
            "message": "注册成功",
            "data": {
                "account": username
            }
        }

    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"数据库写入失败: {str(e)}")
